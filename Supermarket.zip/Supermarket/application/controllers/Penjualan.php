<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Penjualan extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('model_supermarket');
    }

    public function index()
    {
        $data['barang'] = $this->model_supermarket->get_ord('tblbarang', 'barang', 'asc');

        $this->load->view('templates/header');
        $this->load->view('templates/sidebar');
        $this->load->view('penjualan/penjualan_select', $data);
        $this->load->view('templates/footer');
    }

    public function beli($id)
    {
        $barang = $this->model_supermarket->get_one('tblbarang', $id, 'kd_barang');

        if ($barang->stok == 0) {
            $this->session->set_flashdata(
                'message',
                '<div class="alert alert-light alert-dismissible w-100" role="alert">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                Stok barang kosong, tidak dapat membeli barang
            </div>'
            );
            redirect('penjualan');
        } else {
            $dataCart = array(
                'id' => $barang->kd_barang,
                'qty' => 1,
                'price' => $barang->harga,
                'name' => $barang->barang
            );

            $dataBarang = array(
				'stok' => $barang->stok - 1
			);

			$id = array(
				'kd_barang' => $id
			);

			$this->model_supermarket->update('tblbarang', $dataBarang, $id);

            $this->cart->insert($dataCart);
            redirect('penjualan/beli_detail');
        }
    }

    public function beli_detail(){
        $data['cart'] = $this->cart->contents();

        $this->load->view('templates/header');
        $this->load->view('templates/sidebar');
        $this->load->view('penjualan/penjualan_detail', $data);
        $this->load->view('templates/footer');
    }

    public function beli_tambah($id){  
        $barang = $this->model_supermarket->get_one('tblbarang', $id, 'kd_barang');

        if ($barang->stok == 0) {
            $this->session->set_flashdata(
                'message',
                '<div class="alert alert-light alert-dismissible w-100" role="alert">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                Stok barang kosong, tidak dapat membeli barang
            </div>'
            );
            redirect('penjualan/beli_detail');
        } else {
            $data = array(
                'id' => $barang->kd_barang,
                'qty' => +1,
                'price' => $barang->harga,
                'name' => $barang->barang
            );
    
            $dataBarang = array(
                'stok' => $barang->stok - 1
            );
    
            $id = array(
                'kd_barang' => $id
            );
    
            $this->model_supermarket->update('tblbarang', $dataBarang, $id);
    
            $this->cart->insert($data);                              
            redirect('penjualan/beli_detail');
        }        
    }

    public function beli_kurang($rowid, $id){
        $where = $this->cart->get_item($rowid);
        $barang = $this->model_supermarket->get_one('tblbarang', $id, 'kd_barang');
        if ($where['qty'] == 1) {
            $this->cart->remove($rowid);
        } else {
            $data = array(
                'id' => $barang->kd_barang,
                'qty' => -1,
                'price' => $barang->harga,
                'name' => $barang->barang
            );
            $this->cart->insert($data);
        }       
        
        $dataBarang = array(
            'stok' => $barang->stok + 1
        );

        $id = array(
            'kd_barang' => $id
        );

        $this->model_supermarket->update('tblbarang', $dataBarang, $id);
                
        redirect('penjualan/beli_detail');
    }

    public function beli_hapus($rowid, $id, $qty){    
        $barang = $this->model_supermarket->get_one('tblbarang', $id, 'kd_barang');
        $dataBarang = array(
            'stok' => $barang->stok + $qty
        );

        $id = array(
            'kd_barang' => $id
        );

        $this->model_supermarket->update('tblbarang', $dataBarang, $id);

        $this->cart->remove($rowid);

        redirect('penjualan/beli_detail');
    }

    public function checkout() {
        $data['total'] = 0;
        foreach ($this->cart->contents() as $item) {
            $data['total'] = $data['total'] + $item['subtotal'];
        }

        $data['pelanggan'] = $this->model_supermarket->get_ord('tblpelanggan', 'nama', 'asc');

        if ($data['pelanggan'] == null) {
            $this->session->set_flashdata('message', 
            '<div class="alert alert-light alert-dismissible w-100" role="alert">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                Data pelanggan kosong, mohon di isi terlebih dahulu
            </div>');
            redirect('penjualan/beli_detail');
        } else {
            $this->load->view('templates/header');
            $this->load->view('templates/sidebar');
            $this->load->view('penjualan/penjualan_bayar', $data);
            $this->load->view('templates/footer');
        }        
    }

    public function bayar($total) {
        $idorder = $this->model_supermarket->idorder();

        $idpelanggan = $this->input->post('idpelanggan');

        $bayar = $this->input->post('total_bayar');

        $kembali = (int)$bayar - (int)$total;

        if ($bayar < $total) {
            $this->session->set_flashdata('message', 
                '<div class="alert alert-light alert-dismissible" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    Pembayaran Kurang
                </div>');
            redirect('penjualan/checkout');
        } else {
            foreach ($this->cart->contents() as $item) {
                $orderdetail = array(
                    'idorder' => $idorder,
                    'kd_barang' => $item['id'],
                    'jumlah' => $item['qty'],
                    'harga' => $item['price']
                );
                $this->model_supermarket->insert("tblorderdetail", $orderdetail);
            }
    
            $order = array(
                'idorder' => $idorder,
                'idpelanggan' => $idpelanggan,
                'idpegawai' => $this->session->idpegawai,
                'tglorder' => date('Y-m-d'),
                'total' => $total,
                'bayar' => $bayar,
                'kembali' => $kembali
            );
            $this->model_supermarket->insert("tblorder", $order);                
                        
            $this->cart->destroy();
            $this->session->set_flashdata('message', 
                '<div class="alert alert-light alert-dismissible" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    Transaksi berhasil
                </div>');
            redirect('penjualan');
        }        
    }
}
