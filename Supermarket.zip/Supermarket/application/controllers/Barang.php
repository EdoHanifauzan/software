<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Barang extends CI_Controller {

	public function __construct(){
        parent::__construct();
        $this->load->model('model_supermarket');
    }

    public function index(){			
        $data['barang'] = $this->model_supermarket->get_ord('tblbarang', 'barang', 'asc');

        $this->load->view('templates/header');
        $this->load->view('templates/sidebar');
        $this->load->view('barang/barang_select', $data);
        $this->load->view('templates/footer');
    }

    public function tambah(){
        $data['supplier'] = $this->model_supermarket->get_ord('tblpemasok', 'nama', 'asc');

        if ($data['supplier'] == null) {
            $this->session->set_flashdata('message', 
            '<div class="alert alert-light alert-dismissible w-100" role="alert">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                Data supplier kosong, mohon di isi terlebih dahulu
            </div>');
            redirect('barang');
        } else {
            $this->load->view('templates/header');
            $this->load->view('templates/sidebar');
            $this->load->view('barang/barang_insert', $data);
            $this->load->view('templates/footer');            
        }        
    }
    
    public function proses_tambah(){            
        $data = array(
            'idpemasok' => $this->input->post('idpemasok'),
            'barang' => $this->input->post('barang'),
            'satuan' => $this->input->post('satuan'),
            'stok' => $this->input->post('stok'),
            'harga' => $this->input->post('harga')
        );

        $this->model_supermarket->insert("tblbarang", $data);
        $this->session->set_flashdata('message', 
        '<div class="alert alert-light alert-dismissible w-100" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            Berhasil menambahkan data
        </div>');
        redirect('barang');
    }

    public function hapus($id){
        $where = array('kd_barang' => $id);
        $this->model_supermarket->delete('tblbarang', $where);
        $this->session->set_flashdata('message', 
        '<div class="alert alert-light alert-dismissible w-100" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            Berhasil menghapus data
        </div>');
        redirect('barang');
    }

    public function ubah($id){
        $where = array('kd_barang' => $id);
        $data['barang'] = $this->model_supermarket->get('tblbarang', $where);

        $get = $this->model_supermarket->get_one('tblbarang', $id, 'kd_barang');

        $data['idpemasok'] = $get->idpemasok;
        $data['supplier'] = $this->model_supermarket->get_ord('tblpemasok', 'nama', 'asc');

        $this->load->view('templates/header');
        $this->load->view('templates/sidebar');
        $this->load->view('barang/barang_update', $data);
        $this->load->view('templates/footer');
    }

    public function proses_ubah(){
        $data = array(
            'idpemasok' => $this->input->post('idpemasok'),
            'barang' => $this->input->post('barang'),
            'satuan' => $this->input->post('satuan'),
            'stok' => $this->input->post('stok'),
            'harga' => $this->input->post('harga')
        );

        $id = array(
            'kd_barang' => $this->input->post('barang_id')
        );

        $this->model_supermarket->update('tblbarang', $data, $id);
        $this->session->set_flashdata('message', 
        '<div class="alert alert-light alert-dismissible w-100" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            Berhasil mengubah data
        </div>');
        redirect('barang');
    }
}
