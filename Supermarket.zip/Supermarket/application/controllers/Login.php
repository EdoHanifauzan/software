<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Login extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('model_supermarket');
    }

    public function index()
    {
        $this->load->view('login/login');
    }

    public function register()
    {
        $data['shift'] = ['pagi', 'siang', 'sore', 'malam'];

        $this->load->view('login/register', $data);
    }

    public function auth()
    {
        $username = $this->input->post('username');
        $pass = $this->input->post('password');

        $data = array(
            'username' => $username,
            'password' => $pass
        );

        $auth_pegawai = $this->model_supermarket->get("tblpegawai", $data);
        $get_pegawai = $this->model_supermarket->get_one('tblpegawai', $username, 'username');

        if ($auth_pegawai == TRUE) {
            $this->session->set_userdata(
                array(
                    'username' => $get_pegawai->username,
                    'idpegawai' => $get_pegawai->idpegawai
                )
            );
            redirect('home');
        } else {
            $this->session->set_flashdata(
                'message',
                '<div class="alert alert-light alert-dismissible w-100" role="alert">
                    <button type="button" class="close text-danger" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    Username Atau Password Salah
                </div>'
                    );
            redirect("login");
        }
    }

    public function create()
    {
        $password = $this->input->post('password');
        $konfirmasi = $this->input->post('confirm_password');

        $data = array(
            'username' => $this->input->post('username'),
            'nama' => $this->input->post('nama'),
            'password' => $password,
            'shift' => $this->input->post('shift'),
        );

        if ($password === $konfirmasi) {
            $this->model_supermarket->insert('tblpegawai', $data);
            $this->session->set_flashdata(
                'message',
                '<div class="alert alert-light alert-dismissible w-100" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    Registrasi Berhasil Silahkan Login
                </div>'
                    );
            redirect('login');
        } else {
            $this->session->set_flashdata(
                'message',
                '<div class="alert alert-light alert-dismissible w-100" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    Password Tidak Sama Dengan Konfirmasi
                </div>'
                    );
            redirect('login/register');
        }
    }

    public function logout()
    {
        $this->session->unset_userdata(
            array(
                'username',
                'idpegawai'
            )
        );
        redirect('login');
    }
}
