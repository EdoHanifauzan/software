<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Riwayat extends CI_Controller {

	public function __construct(){
        parent::__construct();
        $this->load->model('model_supermarket');
    }

    public function index(){			
        $data['order'] = $this->model_supermarket->get_ord('tblorder', 'idorder', 'asc');

        $this->load->view('templates/header');
        $this->load->view('templates/sidebar');
        $this->load->view('riwayat/riwayat_select', $data);
        $this->load->view('templates/footer');
    }

    public function detail($idorder, $idpelanggan, $idpegawai){			
        $where = array('idorder' => $idorder);
        $data['orderdetail'] = $this->model_supermarket->get('tblorderdetail', $where);

        // $wherePelanggan = array('idpelanggan' => $idpelanggan);
        $data['pelanggan'] = $this->model_supermarket->get_one('tblpelanggan', $idpelanggan, 'idpelanggan');

        // $wherePegawai = array('idpegawai' => $idpegawai);
        $data['pegawai'] = $this->model_supermarket->get_one('tblpegawai', $idpegawai, 'idpegawai');

        $this->load->view('templates/header');
        $this->load->view('templates/sidebar');
        $this->load->view('riwayat/riwayat_detail', $data);
        $this->load->view('templates/footer');
    }
}
?>