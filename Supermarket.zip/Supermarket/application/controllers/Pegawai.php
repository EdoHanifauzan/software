<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pegawai extends CI_Controller {

	public function __construct(){
        parent::__construct();
        $this->load->model('model_supermarket');
    }

    public function index(){			
        $data['pegawai'] = $this->model_supermarket->get_ord('tblpegawai', 'nama', 'asc');

        $this->load->view('templates/header');
        $this->load->view('templates/sidebar');
        $this->load->view('pegawai/pegawai_select', $data);
        $this->load->view('templates/footer');
    }

    public function tambah(){
        $data['shift'] = ['pagi', 'siang', 'sore', 'malam'];

        $this->load->view('templates/header');
        $this->load->view('templates/sidebar');
        $this->load->view('pegawai/pegawai_insert', $data);
        $this->load->view('templates/footer');            
    }
    
    public function proses_tambah(){            
        $password = $this->input->post('password');
        $konfirmasi = $this->input->post('confirm_password');

        $data = array(
            'username' => $this->input->post('username'),
            'nama' => $this->input->post('nama'),
            'password' => $password,
            'shift' => $this->input->post('shift')
        );

        if ($password === $konfirmasi) {
            $this->model_supermarket->insert("tblpegawai", $data);
            $this->session->set_flashdata('message', 
            '<div class="alert alert-light alert-dismissible w-100" role="alert">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                Berhasil menambahkan data
            </div>');
            redirect('pegawai');
        } else {
            $this->session->set_flashdata(
                'message',
                '<div class="alert alert-light alert-dismissible w-100" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    Password Tidak Sama Dengan Konfirmasi
                </div>'
                    );
            redirect('pegawai/tambah');
        }        
    }

    public function hapus($id){
        $where = array('idpegawai' => $id);
        $this->model_supermarket->delete('tblpegawai', $where);
        $this->session->set_flashdata('message', 
        '<div class="alert alert-light alert-dismissible w-100" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            Berhasil menghapus data
        </div>');
        redirect('pegawai');
    }

    public function ubah($id){
        $where = array('idpegawai' => $id);
        $data['pegawai'] = $this->model_supermarket->get('tblpegawai', $where);

        $data['shift'] = ['pagi', 'siang', 'sore', 'malam'];

        $this->load->view('templates/header');
        $this->load->view('templates/sidebar');
        $this->load->view('pegawai/pegawai_update', $data);
        $this->load->view('templates/footer');
    }

    public function proses_ubah(){
        $password = $this->input->post('password');
        $konfirmasi = $this->input->post('confirm_password');

        $data = array(
            'username' => $this->input->post('username'),
            'nama' => $this->input->post('nama'),
            'password' => $password,
            'shift' => $this->input->post('shift')
        );

        if ($password === $konfirmasi) {
            $id = array(
                'idpegawai' => $this->input->post('pegawai_id')
            );

            if ($this->input->post('pegawai_id') === $this->session->idpegawai) {
                $this->session->set_userdata(
                    array(
                        'username' => $this->input->post('username'),
                        'idpegawai' => $this->input->post('pegawai_id')
                    )
                );
            }            
    
            $this->model_supermarket->update('tblpegawai', $data, $id);
            $this->session->set_flashdata('message', 
            '<div class="alert alert-light alert-dismissible w-100" role="alert">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                Berhasil mengubah data
            </div>');
            redirect('pegawai');
        } else {
            $this->session->set_flashdata(
                'message',
                '<div class="alert alert-light alert-dismissible w-100" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    Password Tidak Sama Dengan Konfirmasi
                </div>'
                    );
            redirect('pegawai/ubah/' .$this->input->post('pegawai_id'));
        }        
    }
}
