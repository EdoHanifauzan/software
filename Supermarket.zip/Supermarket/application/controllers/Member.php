<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Member extends CI_Controller {

	public function __construct(){
        parent::__construct();
        $this->load->model('model_supermarket');
    }

    public function index(){			
        $data['nama'] = $this->model_supermarket->get_ord('tblpelanggan', 'nama', 'asc');

        $this->load->view('templates/header');
        $this->load->view('templates/sidebar');
        $this->load->view('member/member_select', $data);
        $this->load->view('templates/footer');
    }

    public function tambah(){
        $this->load->view('templates/header');
        $this->load->view('templates/sidebar');
        $this->load->view('member/member_insert');
        $this->load->view('templates/footer');            
    }
    
    public function proses_tambah(){            
        $data = array(
            'nama' => $this->input->post('nama'),
            'alamat' => $this->input->post('alamat'),
            'telpon' => $this->input->post('telpon')
        );

        $this->model_supermarket->insert("tblpelanggan", $data);
        $this->session->set_flashdata('message', 
        '<div class="alert alert-light alert-dismissible w-100" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            Berhasil menambahkan data
        </div>');
        redirect('member');
    }

    public function hapus($id){
        $where = array('idpelanggan' => $id);
        $this->model_supermarket->delete('tblpelanggan', $where);
        $this->session->set_flashdata('message', 
        '<div class="alert alert-light alert-dismissible w-100" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            Berhasil menghapus data
        </div>');
        redirect('member');
    }

    public function ubah($id){
        $where = array('idpelanggan' => $id);
        $data['member'] = $this->model_supermarket->get('tblpelanggan', $where);

        $this->load->view('templates/header');
        $this->load->view('templates/sidebar');
        $this->load->view('member/member_update', $data);
        $this->load->view('templates/footer');
    }

    public function proses_ubah(){
        $data = array(
            'nama' => $this->input->post('nama'),
            'alamat' => $this->input->post('alamat'),
            'telpon' => $this->input->post('telpon')
        );

        $id = array(
            'idpelanggan' => $this->input->post('member_id')
        );

        $this->model_supermarket->update('tblpelanggan', $data, $id);
        $this->session->set_flashdata('message', 
        '<div class="alert alert-light alert-dismissible w-100" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            Berhasil mengubah data
        </div>');
        redirect('member');
    }
}
