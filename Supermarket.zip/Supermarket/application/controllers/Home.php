<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	public function __construct(){
        parent::__construct();
        $this->load->model('model_supermarket');
    }

    public function index(){			
        $data['pelanggan'] = $this->db->count_all('tblpelanggan');
        $data['pemasok'] = $this->db->count_all('tblpemasok');
        $data['pegawai'] = $this->db->count_all('tblpegawai');
        $data['barang'] = $this->db->count_all('tblbarang');
        $data['order'] = $this->db->count_all('tblorder');

        $this->load->view('templates/header');
        $this->load->view('templates/sidebar');
        $this->load->view('home', $data);
        $this->load->view('templates/footer');
    }
}
