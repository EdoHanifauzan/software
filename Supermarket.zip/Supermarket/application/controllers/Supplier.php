<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Supplier extends CI_Controller {

	public function __construct(){
        parent::__construct();
        $this->load->model('model_supermarket');
    }

    public function index(){			
        $data['supplier'] = $this->model_supermarket->get_ord('tblpemasok', 'nama', 'asc');

        $this->load->view('templates/header');
        $this->load->view('templates/sidebar');
        $this->load->view('supplier/supplier_select', $data);
        $this->load->view('templates/footer');
    }

    public function tambah(){
        $this->load->view('templates/header');
        $this->load->view('templates/sidebar');
        $this->load->view('supplier/supplier_insert');
        $this->load->view('templates/footer');            
    }
    
    public function proses_tambah(){            
        $data = array(
            'nama' => $this->input->post('nama'),
            'alamat' => $this->input->post('alamat'),
            'telpon' => $this->input->post('telpon')
        );

        $this->model_supermarket->insert("tblpemasok", $data);
        $this->session->set_flashdata('message', 
        '<div class="alert alert-light alert-dismissible w-100" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            Berhasil menambahkan data
        </div>');
        redirect('supplier');
    }

    public function hapus($id){
        $where = array('idpemasok' => $id);
        $this->model_supermarket->delete('tblpemasok', $where);
        $this->session->set_flashdata('message', 
        '<div class="alert alert-light alert-dismissible w-100" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            Berhasil menghapus data
        </div>');
        redirect('supplier');
    }

    public function ubah($id){
        $where = array('idpemasok' => $id);
        $data['supplier'] = $this->model_supermarket->get('tblpemasok', $where);

        $this->load->view('templates/header');
        $this->load->view('templates/sidebar');
        $this->load->view('supplier/supplier_update', $data);
        $this->load->view('templates/footer');
    }

    public function proses_ubah(){
        $data = array(
            'nama' => $this->input->post('nama'),
            'alamat' => $this->input->post('alamat'),
            'telpon' => $this->input->post('telpon')
        );

        $id = array(
            'idpemasok' => $this->input->post('supplier_id')
        );

        $this->model_supermarket->update('tblpemasok', $data, $id);
        $this->session->set_flashdata('message', 
        '<div class="alert alert-light alert-dismissible w-100" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            Berhasil mengubah data
        </div>');
        redirect('supplier');
    }
}
