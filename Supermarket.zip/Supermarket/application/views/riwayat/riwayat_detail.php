        <!-- ============================================================== -->
        <!-- Page Content -->
        <!-- ============================================================== -->
        <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row bg-title">
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                        <h4 class="page-title">Detail Riwayat</h4>
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                <!-- /row -->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="white-box">
                            <table>
                                <tr>
                                    <td>Nama Pelanggan :&nbsp;</td>
                                    <td><?= $pelanggan->nama; ?></td>
                                </tr>
                                <tr>
                                    <td>Alamat :</td>
                                    <td><?= $pelanggan->alamat; ?></td>
                                </tr>
                                <tr>
                                    <td>Telpon :</td>
                                    <td><?= $pelanggan->telpon; ?></td>
                                </tr>
                            </table><hr>
                            <table>
                                <tr>
                                    <td>Nama Pegawai :&nbsp;</td>
                                    <td><?= $pegawai->nama; ?></td>
                                </tr>
                            </table>
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th style="text-align: center; text-transform: capitalize;">No</th>
                                            <th style="text-align: center; text-transform: capitalize;">Nama Barang</th>
                                            <th style="text-align: center; text-transform: capitalize;">Jumlah</th>
                                            <th style="text-align: center; text-transform: capitalize;">Total harga</th>
                                        </tr>
                                    </thead>
                                    <tbody>

                                        <?php
                                        if ($orderdetail == null) {
                                            echo '
                                            <tbody>
                                            <tr>
                                            <td colspan="3" style="text-align: center;">Tidak Ada Data</td>
                                            </tr>
                                            </tbody>                
                                            </table>
                                            ';
                                        } else {
                                            $no = 1;
                                            $this->load->model('model_supermarket');
                                            foreach ($orderdetail as $ord) : 
                                            $barang = $this->model_supermarket->get_one('tblbarang', $ord->kd_barang, 'kd_barang'); ?>
                                                <tr style="text-align: center;">
                                                    <td><?= $no++; ?></td>
                                                    <td><?= $barang->barang ?></td>
                                                    <td><?= $ord->jumlah ?></td>
                                                    <td><?= $ord->harga ?></td>
                                                </tr>
                                            <?php
                                            endforeach; ?>
                                    </tbody>
                                <?php
                                        }
                                ?>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- ============================================================== -->
        <!-- End Page Content -->
        <!-- ============================================================== -->