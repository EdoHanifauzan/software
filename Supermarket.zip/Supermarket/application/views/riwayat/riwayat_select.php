        <!-- ============================================================== -->
        <!-- Page Content -->
        <!-- ============================================================== -->
        <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row bg-title">
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                        <h4 class="page-title">Riwayat</h4>
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                <!-- /row -->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="white-box">
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th style="text-align: center; text-transform: capitalize;">No</th>
                                            <th style="text-align: center; text-transform: capitalize;">Nama Pelanggan</th>
                                            <th style="text-align: center; text-transform: capitalize;">Tanggal Order</th>
                                            <th style="text-align: center; text-transform: capitalize;">Total</th>
                                            <th style="text-align: center; text-transform: capitalize;">Bayar</th>
                                            <th style="text-align: center; text-transform: capitalize;">Kembali</th>
                                            <th style="text-align: center; text-transform: capitalize;">Detail</th>
                                        </tr>
                                    </thead>
                                    <tbody>

                                        <?php
                                        if ($order == null) {
                                            echo '
                                            <tbody>
                                            <tr>
                                            <td colspan="6" style="text-align: center;">Tidak Ada Data</td>
                                            </tr>
                                            </tbody>                
                                            </table>
                                            ';
                                        } else {
                                            $no = 1;
                                            $this->load->model('model_supermarket');
                                            foreach ($order as $ord) : 
                                            $pelanggan = $this->model_supermarket->get_one('tblpelanggan', $ord->idpelanggan, 'idpelanggan'); ?>
                                                <tr style="text-align: center;">
                                                    <td><?= $no++; ?></td>
                                                    <td><?= $pelanggan->nama; ?></td>
                                                    <td><?= $ord->tglorder ?></td>
                                                    <td><?= $ord->total ?></td>
                                                    <td><?= $ord->bayar ?></td>
                                                    <td><?= $ord->kembali ?></td>
                                                    <td><?= anchor('riwayat/detail/' . $ord->idorder . '/' . $ord->idpelanggan . '/' . $ord->idpegawai, '<div class="btn btn-success btn-m"><i class="fa fa-search"></i></div>') ?></td>
                                                </tr>
                                            <?php
                                            endforeach; ?>
                                    </tbody>
                                <?php
                                        }
                                ?>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- ============================================================== -->
        <!-- End Page Content -->
        <!-- ============================================================== -->