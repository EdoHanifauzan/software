<?php if ($this->session->idpegawai) {
    header("location:" . base_url());
} ?>

<!DOCTYPE html>
<html lang="en" style="background-color: #edf1f5;">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" type="image/png" sizes="16x16" href="<?= base_url() ?>assets/plugins/images/favicon.png">
    <title>Supermarket</title>
    <!-- Bootstrap Core CSS -->
    <link href="<?= base_url() ?>assets/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Menu CSS -->
    <link href="<?= base_url() ?>assets/plugins/bower_components/sidebar-nav/dist/sidebar-nav.min.css" rel="stylesheet">
    <!-- toast CSS -->
    <link href="<?= base_url() ?>assets/plugins/bower_components/toast-master/css/jquery.toast.css" rel="stylesheet">
    <!-- morris CSS -->
    <link href="<?= base_url() ?>assets/plugins/bower_components/morrisjs/morris.css" rel="stylesheet">
    <!-- chartist CSS -->
    <link href="<?= base_url() ?>assets/plugins/bower_components/chartist-js/dist/chartist.min.css" rel="stylesheet">
    <link href="<?= base_url() ?>assets/plugins/bower_components/chartist-plugin-tooltip-master/dist/chartist-plugin-tooltip.css" rel="stylesheet">
    <!-- animation CSS -->
    <link href="<?= base_url() ?>assets/css/animate.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="<?= base_url() ?>assets/css/style.css" rel="stylesheet">
    <!-- color CSS -->
    <link href="<?= base_url() ?>assets/css/colors/default.css" id="theme" rel="stylesheet">
</head>

<body style="background-color: #edf1f5;">
    <!-- ============================================================== -->
    <!-- Page Content -->
    <!-- ============================================================== -->
    <div>
        <div class="container-fluid">
            <div class="row bg-title" style="background-color: #edf1f5;">
                <!-- /.col-lg-12 -->
            </div>
            <!-- /row -->
            <div class="row">
                <div class="col-sm-12">
                    <div class="white-box" style="width: 40%; margin: auto; margin-top: 4%;">
                        <h1 class="page-title" style="text-align: center;">Register</h1>
                        <div class="mt-5 mb-5"><?= $this->session->flashdata('message') ?></div>
                        <form action="<?= base_url('login/create') ?>" method="post" class="form-horizontal form-material" style="padding: 2%;">

                            <div class="form-group">
                                <label style="font-size:15px;">Username</label>
                                <input type="text" name="username" placeholder="Username" required class="form-control">
                            </div>

                            <div class="form-group">
                                <label style="font-size:15px;">Nama</label>
                                <input type="text" name="nama" placeholder="Nama" required class="form-control">
                            </div>

                            <div class="form-group">
                                <label style="font-size:15px;">Password</label>
                                <input type="password" id="password" name="password" placeholder="Password" required class="form-control">
                            </div>

                            <div class="form-group">
                                <label style="font-size:15px;">Konfirmasi Password</label>
                                <input type="password" id="confirm_password" name="confirm_password" placeholder="Konfirmasi Password" required class="form-control">
                            </div>

                            <div class="form-group" style="margin-left: -7%;">
                                <div class="container">
                                    <input type="checkbox" onclick="showPassword()" id="check">
                                    <label for="check">&nbsp; Tampilkan password</label>
                                </div>
                            </div>

                            <div class="form-group">
                                <label style="font-size:15px;">Jadwal Shift</label><br>
                                <select name="shift" class="form-control">

                                    <?php foreach ($shift as $sh) : ?>
                                        <option value="<?= $sh ?>"><?= $sh ?></option>
                                    <?php endforeach; ?>

                                </select>
                            </div>

                            <div class="form-group mt-4 text-center">
                                <input type="submit" name="register" value="Register" class="btn btn-info btn-lg btn-block">
                            </div>

                            <div class="form-group text-center">
                                <span>Sudah punya akun? </span><a href="<?= base_url("login") ?>" class="link">Login</a>
                            </div>

                        </form>
                    </div>
                </div>
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </div>
    <!-- ============================================================== -->
    <!-- End Page Content -->
    <!-- ============================================================== -->

    <!-- ============================================================== -->
    <!-- All Jquery -->
    <!-- ============================================================== -->
    <script src="<?= base_url() ?>assets/plugins/bower_components/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap Core JavaScript -->
    <script src="<?= base_url() ?>assets/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- Menu Plugin JavaScript -->
    <script src="<?= base_url() ?>assets/plugins/bower_components/sidebar-nav/dist/sidebar-nav.min.js"></script>
    <!--slimscroll JavaScript -->
    <script src="<?= base_url() ?>assets/js/jquery.slimscroll.js"></script>
    <!--Wave Effects -->
    <script src="<?= base_url() ?>assets/js/waves.js"></script>
    <!--Counter js -->
    <script src="<?= base_url() ?>assets/plugins/bower_components/waypoints/lib/jquery.waypoints.js"></script>
    <script src="<?= base_url() ?>assets/plugins/bower_components/counterup/jquery.counterup.min.js"></script>
    <!-- chartist chart -->
    <script src="<?= base_url() ?>assets/plugins/bower_components/chartist-js/dist/chartist.min.js"></script>
    <script src="<?= base_url() ?>assets/plugins/bower_components/chartist-plugin-tooltip-master/dist/chartist-plugin-tooltip.min.js"></script>
    <!-- Sparkline chart JavaScript -->
    <script src="<?= base_url() ?>assets/plugins/bower_components/jquery-sparkline/jquery.sparkline.min.js"></script>
    <!-- Custom Theme JavaScript -->
    <script src="<?= base_url() ?>assets/js/custom.min.js"></script>
    <script src="<?= base_url() ?>assets/js/dashboard1.js"></script>
    <script src="<?= base_url() ?>assets/plugins/bower_components/toast-master/js/jquery.toast.js"></script>

    <script>
        function showPassword() {
            var pass = document.getElementById("password");
            var confPass = document.getElementById("confirm_password");
            if (pass.type === "password" && confPass.type === "password") {
                pass.type = "text";
                confPass.type = "text";
            } else {
                pass.type = "password";
                confPass.type = "password";
            }
        }
    </script>
</body>

</html>