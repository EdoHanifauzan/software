        <!-- ============================================================== -->
        <!-- Page Content -->
        <!-- ============================================================== -->
        <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row bg-title">
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                        <h4 class="page-title">Supplier</h4>
                    </div>
                    <div class="col-lg-9 col-sm-8 col-md-8 col-xs-12">
                        <a href="<?= base_url('supplier/tambah') ?>" class="btn btn-info pull-right m-l-20 waves-effect waves-light"><i class="fa fa-plus"></i> Tambah Data</a>
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                <!-- /row -->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="white-box">
                            <div class="mt-1 mb-5"><?= $this->session->flashdata('message') ?></div>
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th style="text-align: center; text-transform: capitalize;">No</th>
                                            <th style="text-align: center; text-transform: capitalize;">Nama</th>
                                            <th style="text-align: center; text-transform: capitalize;">Alamat</th>
                                            <th style="text-align: center; text-transform: capitalize;">Telpon</th>
                                            <th style="text-align: center; text-transform: capitalize;" colspan="2">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>

                                        <?php
                                        if ($supplier == null) {
                                            echo '
                                            <tbody>
                                            <tr>
                                            <td colspan="5" style="text-align: center;">Tidak Ada Data</td>
                                            </tr>
                                            </tbody>                
                                            </table>
                                            ';
                                        } else {
                                            $no = 1;
                                            foreach ($supplier as $sup) : ?>

                                                <tr style="text-align: center;">
                                                    <td><?= $no++; ?></td>
                                                    <td><?= $sup->nama ?></td>
                                                    <td><?= $sup->alamat ?></td>
                                                    <td><?= $sup->telpon ?></td>
                                                    <td onclick="javasript: return confirm('Anda Yakin Ingin Menghapus?')"><?= anchor('supplier/hapus/' . $sup->idpemasok, '<div class="btn btn-danger btn-m"><i class="fa fa-trash"></i></div>') ?></td>
                                                    <td><?= anchor('supplier/ubah/' . $sup->idpemasok, '<div class="btn btn-warning btn-m"><i class="fa fa-edit"></i></div>') ?></td>
                                                </tr>
                                            <?php
                                            endforeach; ?>
                                    </tbody>
                                <?php
                                        }
                                ?>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- ============================================================== -->
        <!-- End Page Content -->
        <!-- ============================================================== -->