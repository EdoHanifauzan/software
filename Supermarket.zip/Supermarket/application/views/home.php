        <!-- ============================================================== -->
        <!-- Page Content -->
        <!-- ============================================================== -->
        <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row bg-title">
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                        <h4 class="page-title">Dashboard</h4>
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                <!-- /.row -->
                <!-- ============================================================== -->
                <!-- Different data widgets -->
                <!-- ============================================================== -->
                <!-- .row -->
                <div class="row">
                    <div class="col-lg-4 col-sm-6 col-xs-12">
                        <div class="white-box analytics-info">
                            <h3 class="box-title">Total Pelanggan</h3>
                                                            
                                <p class="text-right" style="font-size: 24px;"><i class="ti-arrow-up text-success"></i> <span class="text-success"><?= $pelanggan; ?></span></p>
                            
                        </div>
                    </div>
                    <div class="col-lg-4 col-sm-6 col-xs-12">
                        <div class="white-box analytics-info">
                            <h3 class="box-title">Total Supplier</h3>
                                                            
                                <p class="text-right" style="font-size: 24px;"><i class="ti-arrow-up text-purple"></i> <span class="text-purple"><?= $pemasok; ?></span></p>
                            
                        </div>
                    </div>
                    <div class="col-lg-4 col-sm-6 col-xs-12">
                        <div class="white-box analytics-info">
                            <h3 class="box-title">Total Pegawai</h3>
                                                            
                                <p class="text-right" style="font-size: 24px;"><i class="ti-arrow-up text-info"></i> <span class="text-info"><?= $pegawai; ?></span></p>
                            
                        </div>
                    </div>
                    <div class="col-lg-4 col-sm-6 col-xs-12">
                        <div class="white-box analytics-info">
                            <h3 class="box-title">Total Barang</h3>
                                                            
                                <p class="text-right" style="font-size: 24px;"><i class="ti-arrow-up text-danger"></i> <span class="text-danger"><?= $barang; ?></span></p>
                            
                        </div>
                    </div>
                    <div class="col-lg-4 col-sm-6 col-xs-12">
                        <div class="white-box analytics-info">
                            <h3 class="box-title">Total Penjualan</h3>
                                                            
                                <p class="text-right" style="font-size: 24px;"><i class="ti-arrow-up text-warning"></i> <span class="text-warning"><?= $order; ?></span></p>
                            
                        </div>
                    </div>
                </div>
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- ============================================================== -->
        <!-- End Page Content -->
        <!-- ============================================================== -->