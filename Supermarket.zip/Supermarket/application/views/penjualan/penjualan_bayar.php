        <!-- ============================================================== -->
        <!-- Page Content -->
        <!-- ============================================================== -->
        <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row bg-title">
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                        <h4 class="page-title">Penjualan</h4>
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                <!-- /row -->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="white-box">
                            <div class="mt-1 mb-5"><?= $this->session->flashdata('message') ?></div>
                            <form action="<?= base_url('penjualan/bayar/' .$total) ?>" method="post" class="form-horizontal form-material" style="padding: 2%;">

                                <div class="form-group">
                                    <label style="font-size:15px;">Nama Pelanggan</label><br>
                                    <select name="idpelanggan" class="form-control">

                                        <?php foreach ($pelanggan as $pel) : ?>
                                            <option value="<?= $pel->idpelanggan ?>"><?= $pel->nama ?></option>
                                        <?php endforeach; ?>

                                    </select>
                                </div>

                                <div class="form-group">
                                    <label style="font-size:15px;">Total</label>
                                    <input type="number" name="total" placeholder="Total" value="<?= $total; ?>" disabled required class="form-control">
                                </div>

                                <div class="form-group">
                                    <label style="font-size:15px;">Total Pembayaran</label>
                                    <input type="text" name="total_bayar" placeholder="Total Pembayaran" required class="form-control">
                                </div>

                                <div class="form-group mt-4 text-center">
                                    <input type="submit" name="bayar" value="Bayar" class="btn btn-info btn-lg btn-block">
                                </div>

                            </form>
                        </div>
                    </div>
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- ============================================================== -->
        <!-- End Page Content -->
        <!-- ============================================================== -->