        <!-- ============================================================== -->
        <!-- Page Content -->
        <!-- ============================================================== -->
        <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row bg-title">
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                        <h4 class="page-title">Detail Penjualan</h4>
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                <!-- /row -->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="white-box">
                            <div class="mt-1 mb-5"><?= $this->session->flashdata('message') ?></div>
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th style="text-align: center; text-transform: capitalize;">No</th>
                                            <th style="text-align: center; text-transform: capitalize;">Nama Barang</th>
                                            <th style="text-align: center; text-transform: capitalize;">Harga</th>
                                            <th style="text-align: center; text-transform: capitalize;">Jumlah</th>
                                            <th style="text-align: center; text-transform: capitalize;">Hapus</th>
                                            <th style="text-align: center; text-transform: capitalize;">Total</th>
                                        </tr>
                                    </thead>

                                    <tbody>
                                        <?php
                                        if ($cart == null) {
                                            echo '
                                            <tbody>
                                            <tr>
                                            <td colspan="6" style="text-align: center;">Keranjang Kosong</td>
                                            </tr>
                                            </tbody>                
                                            </table>
                                            ';
                                        } else {
                                            $total = 0;
                                            $no = 1;
                                            foreach ($cart as $item) : ?>
                                                <tr style="text-align: center;">
                                                    <td><?php echo $no++ ?></td>
                                                    <td><?php echo $item['name'] ?></td>
                                                    <td><?php echo $item['price'] ?></td>
                                                    <td>
                                                        <?php echo anchor('penjualan/beli_tambah/' . $item['id'], '<div class="btn btn-success btn-sm" id="btn_plus"><i class="fa fa-plus"></i></div>'); ?>&nbsp;&nbsp;
                                                        <input style="width:50px; text-align:center;" type="text" disabled value="<?php echo $item['qty'] ?>">&nbsp;&nbsp;
                                                        <?php echo anchor('penjualan/beli_kurang/' . $item['rowid'] . '/' . $item['id'], '<div class="btn btn-success btn-sm" id="btn_minus"><i class="fa fa-minus"></i></div>'); ?>
                                                    </td>
                                                    <td><a class="btn btn-danger btn-sm" href="<?= base_url('penjualan/beli_hapus/') . $item['rowid'] . '/' . $item['id'] . '/' . $item['qty'] ?>">Hapus</a></td>
                                                    <td><?php echo $item['subtotal'] ?></td>
                                                </tr>
                                            <?php

                                                $total = $total + $item['subtotal'];

                                            endforeach; ?>
                                            <tr>
                                                <td colspan="5">
                                                    <h3>Total :</h3>
                                                </td>

                                                <td style="text-align: center;">
                                                    <h4><?= $total ?></h4>
                                                </td>
                                            </tr>
                                        <?php } ?>
                                    </tbody>
                                </table>
                                <?php if (!empty($total)) { ?>
                                    <a href="<?= base_url('penjualan/checkout') ?>" class="btn btn-info pull-right m-l-20 waves-effect waves-light">Checkout</a>
                                <?php } ?>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- ============================================================== -->
        <!-- End Page Content -->
        <!-- ============================================================== -->