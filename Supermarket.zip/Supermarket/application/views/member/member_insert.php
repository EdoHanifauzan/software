        <!-- ============================================================== -->
        <!-- Page Content -->
        <!-- ============================================================== -->
        <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row bg-title">
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                        <h4 class="page-title">Tambah Pelanggan</h4>
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                <!-- /row -->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="white-box">
                            <form action="<?= base_url('member/proses_tambah') ?>" method="post" class="form-horizontal form-material" style="padding: 2%;">

                                <div class="form-group">
                                    <label style="font-size:15px;">Nama</label>
                                    <input type="text" name="nama" placeholder="Nama" required class="form-control">
                                </div>

                                <div class="form-group">
                                    <label style="font-size:15px;">Alamat</label>
                                    <input type="text" name="alamat" placeholder="Alamat" required class="form-control">
                                </div>

                                <div class="form-group">
                                    <label style="font-size:15px;">Telpon</label>
                                    <input type="number" name="telpon" placeholder="Telpon" required class="form-control" min="0">
                                </div>

                                <div class="form-group mt-4 text-center">
                                    <input type="submit" name="simpan" value="Simpan" class="btn btn-info btn-lg btn-block">
                                </div>

                            </form>
                        </div>
                    </div>
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- ============================================================== -->
        <!-- End Page Content -->
        <!-- ============================================================== -->