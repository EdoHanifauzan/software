        <!-- ============================================================== -->
        <!-- Page Content -->
        <!-- ============================================================== -->
        <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row bg-title">
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                        <h4 class="page-title">Ubah Pegawai</h4>
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                <!-- /row -->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="white-box">
                            <?php foreach ($pegawai as $peg) : ?>
                            <div class="mt-1 mb-5"><?= $this->session->flashdata('message') ?></div>
                            <form action="<?= base_url('pegawai/proses_ubah') ?>" method="post" class="form-horizontal form-material" style="padding: 2%;">

                                <input type="hidden" name="pegawai_id" value="<?= $peg->idpegawai ?>" class="form-control">

                                <div class="form-group">
                                    <label style="font-size:15px;">Username</label>
                                    <input type="text" name="username" placeholder="Username" required value="<?= $peg->username?>" class="form-control">
                                </div>

                                <div class="form-group">
                                    <label style="font-size:15px;">Nama</label>
                                    <input type="text" name="nama" placeholder="Nama" required value="<?= $peg->nama?>" class="form-control">
                                </div>

                                <div class="form-group">
                                    <label style="font-size:15px;">Password</label>
                                    <input type="password" id="password" name="password" placeholder="Password" required value="<?= $peg->password?>" class="form-control">
                                </div>

                                <div class="form-group">
                                    <label style="font-size:15px;">Konfirmasi Password</label>
                                    <input type="password" id="confirm_password" name="confirm_password" placeholder="Konfirmasi Password" required class="form-control">
                                </div>

                                <div class="form-group" style="margin-left: -3%;">
                                    <div class="container">
                                        <input type="checkbox" onclick="showPassword()" id="check">
                                        <label for="check">&nbsp; Tampilkan password</label>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label style="font-size:15px;">Jadwal Shift</label><br>
                                    <select name="shift" class="form-control">

                                        <?php foreach ($shift as $sh) : ?>
                                            <option <?php if ($peg->shift == $sh) echo "selected" ?> value="<?= $sh ?>"><?= $sh ?></option>
                                        <?php endforeach; ?>

                                    </select>
                                </div>

                                <div class="form-group mt-4 text-center">
                                    <input type="submit" name="simpan" value="Simpan" class="btn btn-info btn-lg btn-block">
                                </div>

                            </form>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- ============================================================== -->
        <!-- End Page Content -->
        <!-- ============================================================== -->

        <script>
            function showPassword() {
                var pass = document.getElementById("password");
                var confPass = document.getElementById("confirm_password");
                if (pass.type === "password" && confPass.type === "password") {
                    pass.type = "text";
                    confPass.type = "text";
                } else {
                    pass.type = "password";
                    confPass.type = "password";
                }
            }
        </script>