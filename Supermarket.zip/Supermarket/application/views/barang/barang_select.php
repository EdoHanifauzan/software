        <!-- ============================================================== -->
        <!-- Page Content -->
        <!-- ============================================================== -->
        <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row bg-title">
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                        <h4 class="page-title">Barang</h4>
                    </div>
                    <div class="col-lg-9 col-sm-8 col-md-8 col-xs-12">
                        <a href="<?= base_url('barang/tambah') ?>" class="btn btn-info pull-right m-l-20 waves-effect waves-light"><i class="fa fa-plus"></i> Tambah Data</a>
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                <!-- /row -->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="white-box">
                            <div class="mt-1 mb-5"><?= $this->session->flashdata('message') ?></div>
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th style="text-align: center; text-transform: capitalize;">Kode Barang</th>
                                            <th style="text-align: center; text-transform: capitalize;">Nama Barang</th>
                                            <th style="text-align: center; text-transform: capitalize;">Satuan</th>
                                            <th style="text-align: center; text-transform: capitalize;">Stok</th>
                                            <th style="text-align: center; text-transform: capitalize;">Harga</th>
                                            <th style="text-align: center; text-transform: capitalize;" colspan="2">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>

                                    <?php
                                    if ($barang == null) {
                                        echo '
                                            <tbody>
                                            <tr>
                                            <td colspan="7" style="text-align: center;">Tidak Ada Data</td>
                                            </tr>
                                            </tbody>                
                                            </table>
                                            ';
                                    } else {
                                        foreach ($barang as $bar) : ?>

                                                <tr style="text-align: center;">
                                                    <td><?= $bar->kd_barang ?></td>
                                                    <td><?= $bar->barang ?></td>
                                                    <td><?= $bar->satuan ?></td>
                                                    <td><?= $bar->stok ?></td>
                                                    <td><?= $bar->harga ?></td>
                                                    <td onclick="javasript: return confirm('Anda Yakin Ingin Menghapus?')"><?= anchor('barang/hapus/' . $bar->kd_barang, '<div class="btn btn-danger btn-m"><i class="fa fa-trash"></i></div>') ?></td>
                                                    <td><?= anchor('barang/ubah/' . $bar->kd_barang, '<div class="btn btn-warning btn-m"><i class="fa fa-edit"></i></div>') ?></td>
                                                </tr>
                                            <?php
                                        endforeach; ?>
                                    <?php
                                    }
                                    ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- ============================================================== -->
        <!-- End Page Content -->
        <!-- ============================================================== -->