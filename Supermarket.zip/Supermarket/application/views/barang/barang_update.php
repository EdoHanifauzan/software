        <!-- ============================================================== -->
        <!-- Page Content -->
        <!-- ============================================================== -->
        <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row bg-title">
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                        <h4 class="page-title">Tambah Barang</h4>
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                <!-- /row -->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="white-box">
                            <?php foreach ($barang as $bar) : ?>
                                <form action="<?= base_url('barang/proses_ubah') ?>" method="post" class="form-horizontal form-material" style="padding: 2%;">

                                    <input type="hidden" name="barang_id" value="<?= $bar->kd_barang ?>" class="form-control">

                                    <div class="form-group">
                                        <label style="font-size:15px;">Nama Supplier</label><br>
                                        <select name="idpemasok" class="form-control">

                                            <?php foreach ($supplier as $sup) : ?>
                                                <option <?php if ($idpemasok == $sup->idpemasok) echo "selected" ?> value="<?php echo $sup->idpemasok ?>"><?php echo $sup->nama ?></option>
                                            <?php endforeach; ?>

                                        </select>
                                    </div>

                                    <div class="form-group">
                                        <label style="font-size:15px;">Nama Barang</label>
                                        <input type="text" name="barang" placeholder="barang" required value="<?= $bar->barang ?>" class="form-control">
                                    </div>

                                    <div class="form-group">
                                        <label style="font-size:15px;">Satuan</label>
                                        <input type="text" name="satuan" placeholder="satuan" required value="<?= $bar->satuan ?>" class="form-control">
                                    </div>

                                    <div class="form-group">
                                        <label style="font-size:15px;">Stok</label>
                                        <input type="number" name="stok" placeholder="stok" required value="<?= $bar->stok ?>" class="form-control" min="1">
                                    </div>

                                    <div class="form-group">
                                        <label style="font-size:15px;">Harga</label>
                                        <input type="number" name="harga" placeholder="harga" required value="<?= $bar->harga ?>" class="form-control" min="1">
                                    </div>

                                    <div class="form-group mt-4 text-center">
                                        <input type="submit" name="simpan" value="Simpan" class="btn btn-info btn-lg btn-block">
                                    </div>

                                </form>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- ============================================================== -->
        <!-- End Page Content -->
        <!-- ============================================================== -->