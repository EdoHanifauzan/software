        <!-- ============================================================== -->
        <!-- Page Content -->
        <!-- ============================================================== -->
        <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row bg-title">
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                        <h4 class="page-title">Tambah Barang</h4>
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                <!-- /row -->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="white-box">
                            <form action="<?= base_url('barang/proses_tambah') ?>" method="post" class="form-horizontal form-material" style="padding: 2%;">

                                <div class="form-group">
                                    <label style="font-size:15px;">Nama Supplier</label><br>
                                    <select name="idpemasok" class="form-control">

                                        <?php foreach ($supplier as $sup) : ?>
                                            <option value="<?= $sup->idpemasok ?>"><?= $sup->nama ?></option>
                                        <?php endforeach; ?>

                                    </select>
                                </div>

                                <div class="form-group">
                                    <label style="font-size:15px;">Nama Barang</label>
                                    <input type="text" name="barang" placeholder="barang" required class="form-control">
                                </div>

                                <div class="form-group">
                                    <label style="font-size:15px;">Satuan</label>
                                    <input type="text" name="satuan" placeholder="satuan" required class="form-control">
                                </div>

                                <div class="form-group">
                                    <label style="font-size:15px;">Stok</label>
                                    <input type="number" name="stok" placeholder="stok" required class="form-control" min="1">
                                </div>

                                <div class="form-group">
                                    <label style="font-size:15px;">Harga</label>
                                    <input type="number" name="harga" placeholder="harga" required class="form-control" min="1">
                                </div>

                                <div class="form-group mt-4 text-center">
                                    <input type="submit" name="simpan" value="Simpan" class="btn btn-info btn-lg btn-block">
                                </div>

                            </form>
                        </div>
                    </div>
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- ============================================================== -->
        <!-- End Page Content -->
        <!-- ============================================================== -->